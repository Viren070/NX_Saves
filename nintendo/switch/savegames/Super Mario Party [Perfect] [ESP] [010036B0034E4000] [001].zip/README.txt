Super Mario Party for Nintendo Switch
TRUE 100%

All Characters Unlocked
All Minigames Unlocked
All Gems + Party Crown
Challenge Road 100% (Normal Mode)
Challenge Road 100% (Master Mode)
All Stickers
All Shiny Stickers

By KayShyGuy

Happy Partying! :)